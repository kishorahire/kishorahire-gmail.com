package com.web.springJunits;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.web.entity.Customer;
import com.web.springdemo.DAO.CustomerDAO;
 
@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class TestCustomerDAO 
{
     
    @Autowired
    private CustomerDAO customerDAO;
     

    @Test
    @Transactional
    @Rollback(true)
    public void testCustomerData()
    {
        Customer customer = new Customer("First","Last","email@ad.com",1234);
        List<Customer> customers = customerDAO.getCustomers();
        
        Assert.assertEquals(customers.get(0).getFirst_name(), "First");
    }
     
    @Test
    @Transactional
    @Rollback(true)
    public void testAddEmployee()
    {
        Customer customer = new Customer();
        customer.setFirst_name("Kishor");
        customer.setLast_name("Ahire");
        customer.setEmail("kishorahire@gmail.com");
        customer.setPhone(89787983);
         
        customerDAO.saveCustomers(customer);         
        List<Customer> customers = customerDAO.getCustomers();
         
        Assert.assertEquals(1, customers.size());
         
        Assert.assertEquals(customer.getFirst_name(), customers.get(0).getFirst_name());
        Assert.assertEquals(customer.getEmail(), customers.get(0).getEmail());
    }
}