package com.web.springdemo.service;

import java.util.List;

import com.web.entity.Customer;

public interface CustomerService {

	List<Customer> getCustomer();

	public void saveCustomer(Customer customer);

	Customer getCustomer(int id);

	void deleteCustomer(int id);

}
