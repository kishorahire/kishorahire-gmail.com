package com.web.springdemo.aspect;

import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class CRMLoggingAspect {

	private Logger logger = Logger.getLogger(getClass().getName());

	@Pointcut("execution(* com.web.springdemo.DAO.*.*(..))")
	public void forDaoPackage() {
	}

	@Pointcut("execution(* com.web.springdemo.service.*.*(..))")
	public void forServicePackage() {
	}

	@Pointcut("execution(* com.web.springdemo.controller.*.*(..))")
	public void forControllerPackage() {
	}

	@Pointcut("forControllerPackage() ||forServicePackage() ||  forDaoPackage()")
	public void forAppFlow() {
	}

	@Before("forAppFlow()")
	public void before(JoinPoint tjp) {
		logger.info("===> in @Before " + tjp.getSignature().toShortString());
	}
	
	@AfterReturning(pointcut = "forAppFlow()", returning = "result")
	public void afterReturningAdvice(JoinPoint tjp, Object result)
	{
		logger.info("Result is -->> ** " + result);
	}

}
