package com.web.springdemo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.web.entity.Customer;
import com.web.springdemo.service.CustomerService;

@Controller
@RequestMapping("/Customer")
public class CustomerController {

	@Autowired
	private CustomerService custservice;
	
	@RequestMapping("/list")
	public String listCustomers(Model model)
	{
		List<Customer> cust = custservice.getCustomer();
		model.addAttribute("customers", cust);
		return "list-customers";
	}
	
	@RequestMapping("/ShowFormForAdd")
	public String showFormAdd(Model model)
	{
		Customer cust = new Customer();
		model.addAttribute("customer", cust);
		return "ShowFormForAdd";
	}
	
	@PostMapping("/saveCustomer")
	public String saveCustomer(@Valid @ModelAttribute("customer") Customer customer, BindingResult br)
	{

		if (br.hasErrors()) {
			return "ShowFormForAdd";
		}
		
		custservice.saveCustomer(customer);
		return "redirect:/Customer/list";
	}
	
	@GetMapping("/deleteCustomer")
	public String deleteCustomer(@RequestParam("customerId") int id)
	{
		custservice.deleteCustomer(id);
		return "redirect:/Customer/list";

	}
	
	@GetMapping("/showFormForUpdate")
	public String showFormUpdate(@RequestParam("customerId") int id, Model model)
	{
		Customer cust = custservice.getCustomer(id);
		model.addAttribute("customer", cust);
		return "ShowFormForAdd";
	}
	
	@InitBinder
	public void initBinder(WebDataBinder databinder)
	{
		StringTrimmerEditor ste = new StringTrimmerEditor(true);
		databinder.registerCustomEditor(String.class,ste);
	}
	
}
